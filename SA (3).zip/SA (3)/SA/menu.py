import mysql.connector
from tkinter import *
from tkinter import ttk, messagebox
from decimal import Decimal

# Conectar ao banco de dados MySQL
def conectar_bd():
    try:
        conn = mysql.connector.connect(
            host="localhost",        # Endereço do servidor MySQL (pode ser "localhost" se for local)
            user="root",      # Nome de usuário do MySQL
            password="root",    # Senha do MySQL
            database="Guilherme"     # Nome do banco de dados
        )
        return conn
    except mysql.connector.Error as err:
        messagebox.showerror("Erro de Conexão", f"Erro ao conectar ao MySQL: {err}")
        return None

# Criar a tabela de usuários e produtos se não existirem
def criar_tabelas():
    conn = conectar_bd()
    if conn:
        cursor = conn.cursor()
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(255),
            email VARCHAR(255),
            usuario VARCHAR(255) UNIQUE,
            senha VARCHAR(255)
        )
        """)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS produtos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(255),
            preco_kg DECIMAL(10, 2),
            quantidade_kg INT
        )
        """)
        conn.commit()
        conn.close()

# Classe principal para o sistema
class SistemaApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Horta Fresca")
        self.root.geometry("1200x800")
        self.root.configure(background="white")
        self.root.resizable(False, False)

        criar_tabelas()  # Criar as tabelas de usuários e produtos ao iniciar

        # Criando uma frame para cada tela
        self.frames = {}
        for Tela in (LoginTela, RegistroTela, GerenciamentoEstoqueTela, CadastroProdutoTela):
            frame = Tela(parent=root, controller=self)
            self.frames[Tela] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        # Configurando expansão de grid
        root.grid_rowconfigure(0, weight=1)
        root.grid_columnconfigure(0, weight=1)

        # Mostra a tela de login inicialmente
        self.mostrar_tela(LoginTela)

    def mostrar_tela(self, tela_classe):
        frame = self.frames[tela_classe]
        frame.tkraise()

# Tela de Login
class LoginTela(Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(background="white")

        # Quadrado azul e mensagem de "Bem-vindo"
        quadrado_azul = Frame(self, width=400, height=300, bg="MIDNIGHTBLUE")
        quadrado_azul.place(relx=0.5, rely=0.5, anchor=CENTER)

        # Título
        titulo = Label(quadrado_azul, text="LOGIN", font=("Century Gothic", 24), bg="white", fg="MIDNIGHTBLUE")
        titulo.pack(pady=20)

        # Campos de entrada
        usuario_label = Label(quadrado_azul, text="Usuário:", font=("Century Gothic", 14), bg="MIDNIGHTBLUE", fg="white")
        usuario_label.pack(padx=10, pady=5)
        self.usuario_entry = ttk.Entry(quadrado_azul, width=30)
        self.usuario_entry.pack(padx=10, pady=5)

        senha_label = Label(quadrado_azul, text="Senha:", font=("Century Gothic", 14), bg="MIDNIGHTBLUE", fg="white")
        senha_label.pack(padx=10, pady=5)
        self.senha_entry = ttk.Entry(quadrado_azul, width=30, show="•")
        self.senha_entry.pack(padx=10, pady=5)

        # Botões (texto preto e fundo azul)
        estilo = ttk.Style()
        estilo.configure("W.TButton", foreground="black", background="MIDNIGHTBLUE", font=("Century Gothic", 14))

        login_btn = ttk.Button(quadrado_azul, text="Login", command=self.login, width=20, style="W.TButton")
        login_btn.pack(pady=10)

        registro_btn = ttk.Button(quadrado_azul, text="Registrar", command=lambda: self.controller.mostrar_tela(RegistroTela), width=20, style="W.TButton")
        registro_btn.pack(pady=10)

    def login(self):
        usuario = self.usuario_entry.get()
        senha = self.senha_entry.get()

        conn = conectar_bd()
        if conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM usuarios WHERE usuario=%s AND senha=%s", (usuario, senha))
            usuario_encontrado = cursor.fetchone()
            conn.close()

            if usuario_encontrado:
                messagebox.showinfo("Sucesso", "Login realizado com sucesso!")
                self.controller.mostrar_tela(GerenciamentoEstoqueTela)
            else:
                messagebox.showerror("Erro", "Usuário ou senha inválidos.")
        else:
            messagebox.showerror("Erro", "Não foi possível conectar ao banco de dados.")

# Tela de Registro
class RegistroTela(Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(background="white")

        # Quadrado azul e mensagem de "Bem-vindo"
        quadrado_azul = Frame(self, width=400, height=300, bg="MIDNIGHTBLUE")
        quadrado_azul.place(relx=0.5, rely=0.5, anchor=CENTER)

        # Título
        titulo = Label(quadrado_azul, text="REGISTRO", font=("Century Gothic", 24), bg="white", fg="MIDNIGHTBLUE")
        titulo.pack(pady=20)

        # Campos de entrada
        nome_label = Label(quadrado_azul, text="Nome:", font=("Century Gothic", 14), bg="MIDNIGHTBLUE", fg="white")
        nome_label.pack(padx=10, pady=5)
        self.nome_entry = ttk.Entry(quadrado_azul, width=30)
        self.nome_entry.pack(padx=10, pady=5)

        email_label = Label(quadrado_azul, text="Email:", font=("Century Gothic", 14), bg="MIDNIGHTBLUE", fg="white")
        email_label.pack(padx=10, pady=5)
        self.email_entry = ttk.Entry(quadrado_azul, width=30)
        self.email_entry.pack(padx=10, pady=5)

        usuario_label = Label(quadrado_azul, text="Usuário:", font=("Century Gothic", 14), bg="MIDNIGHTBLUE", fg="white")
        usuario_label.pack(padx=10, pady=5)
        self.usuario_entry = ttk.Entry(quadrado_azul, width=30)
        self.usuario_entry.pack(padx=10, pady=5)

        senha_label = Label(quadrado_azul, text="Senha:", font=("Century Gothic", 14), bg="MIDNIGHTBLUE", fg="white")
        senha_label.pack(padx=10, pady=5)
        self.senha_entry = ttk.Entry(quadrado_azul, width=30, show="•")
        self.senha_entry.pack(padx=10, pady=5)

        # Botões (texto preto e fundo azul)
        registrar_btn = ttk.Button(quadrado_azul, text="Registrar", command=self.registrar, width=20, style="W.TButton")
        registrar_btn.pack(pady=10)

        voltar_btn = ttk.Button(quadrado_azul, text="Voltar", command=lambda: self.controller.mostrar_tela(LoginTela), width=20, style="W.TButton")
        voltar_btn.pack(pady=10)

    def registrar(self):
        nome = self.nome_entry.get()
        email = self.email_entry.get()
        usuario = self.usuario_entry.get()
        senha = self.senha_entry.get()

        if nome and email and usuario and senha:
            conn = conectar_bd()
            if conn:
                cursor = conn.cursor()
                cursor.execute("INSERT INTO usuarios (nome, email, usuario, senha) VALUES (%s, %s, %s, %s)", 
                               (nome, email, usuario, senha))
                conn.commit()
                conn.close()
                messagebox.showinfo("Sucesso", "Usuário registrado com sucesso!")
                self.controller.mostrar_tela(LoginTela)
        else:
            messagebox.showerror("Erro", "Preencha todos os campos.")

# Tela de Cadastro de Produto
from decimal import Decimal

class CadastroProdutoTela(Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(background="white")

        # Quadrado azul e mensagem de "Cadastro de Produto"
        quadrado_azul = Frame(self, width=400, height=300, bg="MIDNIGHTBLUE")
        quadrado_azul.place(relx=0.5, rely=0.5, anchor=CENTER)

        # Título
        titulo = Label(quadrado_azul, text="CADASTRO DE PRODUTO", font=("Century Gothic", 14), bg="white", fg="MIDNIGHTBLUE")
        titulo.pack(pady=20)

        # Campos de entrada
        nome_produto_label = Label(quadrado_azul, text="Nome do Produto:", font=("Century Gothic", 12), bg="MIDNIGHTBLUE", fg="white")
        nome_produto_label.pack(padx=10, pady=5)
        self.nome_produto_entry = ttk.Entry(quadrado_azul, width=30)
        self.nome_produto_entry.pack(padx=10, pady=5)

        preco_produto_label = Label(quadrado_azul, text="Preço por Kg:", font=("Century Gothic", 12), bg="MIDNIGHTBLUE", fg="white")
        preco_produto_label.pack(padx=10, pady=5)
        self.preco_produto_entry = ttk.Entry(quadrado_azul, width=30)
        self.preco_produto_entry.pack(padx=10, pady=5)

        quantidade_produto_label = Label(quadrado_azul, text="Quantidade (Kg):", font=("Century Gothic", 12), bg="MIDNIGHTBLUE", fg="white")
        quantidade_produto_label.pack(padx=10, pady=5)
        self.quantidade_produto_entry = ttk.Entry(quadrado_azul, width=30)
        self.quantidade_produto_entry.pack(padx=10, pady=5)

        fornecedor_produto_label = Label(quadrado_azul, text="Fornecedor:", font=("Century Gothic", 12), bg="MIDNIGHTBLUE", fg="white")
        fornecedor_produto_label.pack(padx=10, pady=5)
        self.fornecedor_produto_entry = ttk.Entry(quadrado_azul, width=30)
        self.fornecedor_produto_entry.pack(padx=10, pady=5)


        # Botões
        cadastrar_produto_btn = ttk.Button(quadrado_azul, text="Cadastrar Produto", command=self.cadastrar_produto, width=20, style="W.TButton")
        cadastrar_produto_btn.pack(pady=10)

        voltar_btn = ttk.Button(quadrado_azul, text="Voltar", command=lambda: self.controller.mostrar_tela(GerenciamentoEstoqueTela), width=20, style="W.TButton")
        voltar_btn.pack(pady=10)

    def cadastrar_produto(self):
        nome_produto = self.nome_produto_entry.get()
        preco_produto = self.preco_produto_entry.get()
        quantidade_produto = self.quantidade_produto_entry.get()
        fornecedor_produto = self.fornecedor_produto_entry.get()

        if nome_produto and preco_produto and quantidade_produto:
            try:
                # Converter preco_produto para Decimal e quantidade_produto para int
                preco_produto = Decimal(preco_produto)
                quantidade_produto = int(quantidade_produto)

                # Verifica se o produto já existe no banco
                conn = conectar_bd()
                if conn:
                    cursor = conn.cursor()
                    cursor.execute("SELECT * FROM produtos WHERE nome = %s", (nome_produto,))
                    produto_existente = cursor.fetchone()

                    if produto_existente:
                        # Se o produto já existir, somamos a quantidade e o preço
                        novo_preco = produto_existente[2] + preco_produto
                        nova_quantidade = produto_existente[3] + quantidade_produto

                        # Atualiza o produto existente
                        cursor.execute("""
                            UPDATE produtos
                            SET preco_kg = %s, quantidade_kg = %s
                            WHERE id = %s
                        """, (novo_preco, nova_quantidade, produto_existente[0]))
                        conn.commit()
                        messagebox.showinfo("Sucesso", "Produto atualizado com sucesso!")
                    else:
                        # Se o produto não existir, adiciona um novo
                        cursor.execute("INSERT INTO produtos (nome, preco_kg, quantidade_kg) VALUES (%s, %s, %s)",
                                       (nome_produto, preco_produto, quantidade_produto))
                        conn.commit()
                        messagebox.showinfo("Sucesso", "Produto cadastrado com sucesso!")

                    conn.close()
                    self.controller.mostrar_tela(GerenciamentoEstoqueTela)
            except ValueError:
                messagebox.showerror("Erro", "Preço e Quantidade devem ser numéricos.")
        else:
            messagebox.showerror("Erro", "Preencha todos os campos.")

# Tela de Gerenciamento de Estoque
from tkinter import *
from tkinter import ttk, messagebox
from decimal import Decimal

from tkinter import *
from tkinter import ttk, messagebox
from decimal import Decimal

class GerenciamentoEstoqueTela(Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(background="white")
        
        # Tela de gerenciamento
        titulo = Label(self, text="Gerenciamento de Estoque", font=("Century Gothic", 24), bg="white", fg="MIDNIGHTBLUE")
        titulo.grid(row=0, column=0, columnspan=3, pady=20, padx=10)

        # Campo para filtrar produtos por nome
        self.filtro_nome_label = Label(self, text="Filtrar por Nome do Produto:", font=("Century Gothic", 12), bg="white", fg="MIDNIGHTBLUE")
        self.filtro_nome_label.grid(row=1, column=0, pady=10, padx=10)

        self.filtro_nome_entry = ttk.Entry(self, width=30)
        self.filtro_nome_entry.grid(row=2, column=0, pady=10, padx=10)

        filtro_produto_btn = ttk.Button(self, text="Filtrar", command=self.filtrar_produtos, width=20, style="W.TButton")
        filtro_produto_btn.grid(row=3, column=0, pady=10, padx=10)

        # Botão de Cadastrar Produto
        cadastrar_produto_btn = ttk.Button(self, text="Cadastrar Produto", command=lambda: self.controller.mostrar_tela(CadastroProdutoTela), width=20, style="W.TButton")
        cadastrar_produto_btn.grid(row=4, column=0, pady=10, padx=10)

        # Adicionando a Treeview para exibir produtos
        self.tree = ttk.Treeview(self, columns=("ID", "Nome", "Preço", "Quantidade", "Fornecedor"), show="headings")
        self.tree.grid(row=5, column=0, padx=10, pady=20, columnspan=3, sticky="nsew")

        # Configurando as colunas da Treeview
        self.tree.heading("ID", text="ID")
        self.tree.heading("Nome", text="Nome do Produto")
        self.tree.heading("Preço", text="Preço por Kg")
        self.tree.heading("Quantidade", text="Quantidade (Kg)")
        self.tree.heading("Fornecedor", text="Fornecedor")

        # Carregar produtos na Treeview
        self.carregar_produtos()

        # Campo para informar a quantidade a ser removida
        self.quantidade_remover_label = Label(self, text="Selecione a quantidade para remover:", font=("Century Gothic", 14), bg="white", fg="MIDNIGHTBLUE")
        self.quantidade_remover_label.grid(row=6, column=0, pady=10, padx=10)

        self.quantidade_remover_entry = ttk.Entry(self, width=30)
        self.quantidade_remover_entry.grid(row=7, column=0, pady=10, padx=10)

        # Botão de Remover Produto
        self.remover_produto_btn = Button(self, text="Remover Produto", command=self.remover_produto, width=20, fg="black", bg="red", font=("Arial", 12))
        self.remover_produto_btn.grid(row=8, column=0, padx=10, pady=10)

        # Botão de Alterar Produto
        self.alterar_produto_btn = Button(self, text="Alterar Produto", command=self.alterar_produto, width=20, fg="black", bg="yellow", font=("Arial", 12))
        self.alterar_produto_btn.grid(row=8, column=1, padx=10, pady=10)

        # Botão de Atualizar Estoque
        self.atualizar_produto_btn = Button(self, text="Atualizar Estoque", command=self.atualizar_estoque, width=20, fg="black", bg="green", font=("Arial", 12))
        self.atualizar_produto_btn.grid(row=8, column=2, padx=10, pady=10)

        # Botão de Logout
        logout_btn = Button(self, text="Deslogar", command=self.logout, fg="white", bg="red")
        logout_btn.grid(row=360, column=6, padx=10, pady=10)

    def carregar_produtos(self):
        # Limpa a Treeview antes de carregar os dados
        for item in self.tree.get_children():
            self.tree.delete(item)

        # Conectar ao banco de dados e carregar os produtos
        conn = conectar_bd()
        if conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM produtos")
            produtos = cursor.fetchall()
            conn.close()

            # Adiciona os produtos à Treeview
            for produto in produtos:
                self.tree.insert("", "end", values=produto)

    def filtrar_produtos(self):
        filtro_nome = self.filtro_nome_entry.get().lower()

        # Limpa a Treeview antes de carregar os dados
        for item in self.tree.get_children():
            self.tree.delete(item)

        # Conectar ao banco de dados e carregar produtos filtrados
        conn = conectar_bd()
        if conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM produtos WHERE LOWER(nome) LIKE %s", ('%' + filtro_nome + '%',))
            produtos = cursor.fetchall()
            conn.close()

            # Adiciona os produtos filtrados à Treeview
            for produto in produtos:
                self.tree.insert("", "end", values=produto)

    def alterar_produto(self):
        # Obter o item selecionado na Treeview
        selected_item = self.tree.selection()

        if selected_item:
            produto_id = self.tree.item(selected_item)["values"][0]
            nome_produto = self.tree.item(selected_item)["values"][1]
            preco_produto = self.tree.item(selected_item)["values"][2]
            quantidade_produto = self.tree.item(selected_item)["values"][3]

            # Criar janela de alteração
            alterar_janela = Toplevel(self)
            alterar_janela.title(f"Alterar Produto - {nome_produto}")
            alterar_janela.geometry("300x250")

            # Preencher os campos com os dados do produto selecionado
            Label(alterar_janela, text="Nome do Produto:").pack(pady=5)
            nome_entry = ttk.Entry(alterar_janela)
            nome_entry.insert(0, nome_produto)
            nome_entry.pack(pady=5)

            Label(alterar_janela, text="Preço por Kg:").pack(pady=5)
            preco_entry = ttk.Entry(alterar_janela)
            preco_entry.insert(0, preco_produto)
            preco_entry.pack(pady=5)

            Label(alterar_janela, text="Quantidade (Kg):").pack(pady=5)
            quantidade_entry = ttk.Entry(alterar_janela)
            quantidade_entry.insert(0, quantidade_produto)
            quantidade_entry.pack(pady=5)

            def salvar_alteracoes():
                novo_nome = nome_entry.get()
                novo_preco = preco_entry.get()
                nova_quantidade = quantidade_entry.get()

                # Validações e alteração do produto no banco
                if novo_nome and novo_preco and nova_quantidade:
                    try:
                        novo_preco = Decimal(novo_preco)
                        nova_quantidade = int(nova_quantidade)

                        conn = conectar_bd()
                        if conn:
                            cursor = conn.cursor()
                            cursor.execute("""
                                UPDATE produtos
                                SET nome = %s, preco_kg = %s, quantidade_kg = %s
                                WHERE id = %s
                            """, (novo_nome, novo_preco, nova_quantidade, produto_id))
                            conn.commit()
                            conn.close()

                            messagebox.showinfo("Sucesso", "Produto alterado com sucesso!")
                            self.carregar_produtos()
                            alterar_janela.destroy()
                    except ValueError:
                        messagebox.showerror("Erro", "Preço e Quantidade devem ser válidos.")
                else:
                    messagebox.showerror("Erro", "Preencha todos os campos.")

            # Botão de OK para salvar as alterações
            Button(alterar_janela, text="OK", command=salvar_alteracoes).pack(pady=10)

        else:
            messagebox.showwarning("Seleção Inválida", "Por favor, selecione um produto para alterar.")

    def remover_produto(self):
        # Obter o item selecionado na Treeview
        selected_item = self.tree.selection()

        if selected_item:
            produto_id = self.tree.item(selected_item)["values"][0]
            nome_produto = self.tree.item(selected_item)["values"][1]
            quantidade_estoque = float(self.tree.item(selected_item)["values"][3])
            quantidade_remover = self.quantidade_remover_entry.get()

            if not quantidade_remover.replace('.', '', 1).isdigit():
                messagebox.showerror("Erro", "Por favor, insira uma quantidade válida.")
                return

            quantidade_remover = int(quantidade_remover)

            if quantidade_remover <= 0:
                messagebox.showerror("Erro", "A quantidade a remover deve ser maior que zero.")
                return

            if quantidade_remover > quantidade_estoque:
                messagebox.showerror("Erro", f"A quantidade a remover ({quantidade_remover}) é maior que a quantidade no estoque ({quantidade_estoque}).")
                return

            if quantidade_remover < quantidade_estoque:
                # Atualiza a quantidade do produto
                conn = conectar_bd()
                if conn:
                    cursor = conn.cursor()
                    nova_quantidade = quantidade_estoque - quantidade_remover
                    cursor.execute("UPDATE produtos SET quantidade_kg = %s WHERE id = %s", (nova_quantidade, produto_id))
                    conn.commit()
                    conn.close()
                    messagebox.showinfo("Sucesso", f"Removido {quantidade_remover} Kg do produto {nome_produto}.")
                    self.carregar_produtos()

            elif quantidade_remover == quantidade_estoque:
                # Remove o produto completamente
                resposta = messagebox.askyesno("Confirmar Remoção", f"Você tem certeza que deseja remover completamente o produto {nome_produto}?")
                if resposta:
                    conn = conectar_bd()
                    if conn:
                        cursor = conn.cursor()
                        cursor.execute("DELETE FROM produtos WHERE id = %s", (produto_id,))
                        conn.commit()
                        conn.close()
                        messagebox.showinfo("Sucesso", f"Produto {nome_produto} removido completamente.")
                        self.carregar_produtos()
        else:
            messagebox.showwarning("Seleção Inválida", "Por favor, selecione um produto para remover.")

    def atualizar_estoque(self):
        # Atualiza os produtos e a exibição na Treeview
        self.carregar_produtos()

    def logout(self):
        self.controller.mostrar_tela(LoginTela)





# Inicializando a aplicação
if __name__ == "__main__":
    root = Tk()
    app = SistemaApp(root)
    root.mainloop()
